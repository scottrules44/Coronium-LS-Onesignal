-- copyright Scott Harrison(scottrules44) Aug 6 2016

local api = cloud.api()

local onesignal = require("echo.onesignal")--replace echo with app name

function api.post.test( in_data )
	return in_data
end

function api.post.viewApps( input )
	return {onesignal.viewApps(input)}
end

function api.post.getAppInfo( input )
	return {onesignal.getAppInfo(input)}
end

function api.post.makeApp( input )
	return {onesignal.makeApp(input)}
end

function api.post.updateApp( input )
	return {onesignal.updateApp(input)}
end

function api.post.viewDevices( input )
	return {onesignal.viewDevices(input)}
end

function api.post.viewDeviceInfo( input )
	return {onesignal.viewDeviceInfo(input.token)}
end

function api.post.registerDevice( input )
	return {onesignal.registerDevice(input)}
end

function api.post.updateDevice( input )
	return {onesignal.pushAll(input)}
end

function api.post.callSession( input )
	return {onesignal.callSession()}
end

function api.post.purchaseMade( input )
	return {onesignal.purchaseMade(input)}
end

function api.post.getCsvUrl( input )
	return {onesignal.getCsvUrl(input)}
end

function api.post.getNotificationInfo( input )
	return {onesignal.deleteByAlias(input)}
end

function api.post.getNotifications( input )
	return {onesignal.getNotifications(input)}
end

function api.post.trackOpen( input )
	return {onesignal.trackOpen(input)}
end

function api.post.createNotfication( input )
	return {onesignal.createNotfication(input)}
end

function api.post.cancelNotfication( input )
	return {onesignal.registerDevices(input)}
end

return api